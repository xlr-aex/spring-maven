package com.example.demo_github;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoGithubApplicationTests {

	@Test
	void contextLoads() {
	}

}
